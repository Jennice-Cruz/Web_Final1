<?php # Script 18.6 - register.php
// This is the registration page for the site.
//require ('includes/config.inc.php');
$page_title = 'Register';
include ('includes/header.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') { // Handle the form

	
	// Trim all the incoming data:
	$trimmed = array_map('trim', $_POST);
	
	// Assume invalid values:
	$fn = $ln = $e = $p = FALSE;

	// Check for a first name:
	if (preg_match ('/^[A-Z \'.-]{2,20}$/i',$trimmed['first_name'])) {
		$fn = $trimmed['first_name'];	
	} else {
		echo '<p class="error">Please enter your first name!</p>';
	}
	
	// Check for a last name:
	if (preg_match ('/^[A-Z \'.-]{2,40}$/i',$trimmed['last_name'])) {
		$ln =$trimmed['last_name'];	
	} else {
		echo '<p class="error">Please enter your last name!</p>';
	}

	// Check for an email address:
	if (filter_var($trimmed['email'],FILTER_VALIDATE_EMAIL)) {
		$e =$trimmed['email'];
	} else {
		echo '<p class="error">Please enter a valid email address.';		
	}

	// Check for a password and match againt the confirmed password:
	if (preg_match ('/^\w{4,20}$/', $trimmed['password1'])) {
		if ($trimmed['password1'] == $trimmed['password2']){
			$p = $trimmed['password1'];	
		} else {
			echo '<p class="error">Your password did not match the confirmed password</p>';
		}
	} else {
		echo '<p class="error">Please enter a valid password!</p>';
	}

	//check for address
	if(isset($_POST['address'])){
		$add = $_POST['address'];
	}
	else{
		echo '<p class="error">Please enter your address!</p>';
	}

	//check for city
	if(isset($_POST['city'])){
		$city = $_POST['city'];
	}
	else{
		echo '<p class="error">Please enter your city!</p>';
	}

	//check for state
	if(isset($_POST['state'])){
		$state = $_POST['state'];
	}
	else{
		echo '<p class="error">Please enter your state!</p>';
	}

	//check for zipcode
	if(isset($_POST['postal_code'])){
			$zip = $_POST['postal_code'];
	}
	else{
		echo '<p class="error">Please enter your postal code!</p>';
	}

	if ($fn && $ln && $e && $p && $add && $city && $state && $zip) { // If everything's OK.
		
		
		// Print thank you message:
		echo '<h3>Thank you for registering!</h3>';
		include ('includes/footer.php'); // Include the HTML footer.
		exit(); // Stop the page.
		
		
	} else { // If one of the data tests failed.
		echo '<p class="error">Please try again.</p>';
	}
	
	
} // End of the main Submit conditional.
?>
		
<h1 align="center">Register</h1>
<form action="register.php" method="post">
	
	<p><b>First Name:</b> <input type="text" name="first_name" size="20" maxlength="20" value="<?php if (isset($trimmed['first_name'])) echo $trimmed['first_name']; ?>" /></p>
	
	<p><b>Last Name:</b> <input type="text" name="last_name" size="20" maxlength="40" value="<?php if (isset($trimmed['last_name'])) echo $trimmed['last_name']; ?>" /></p>
	
	<p><b>Email Address:</b> <input type="text" name="email" size="30" maxlength="60" value="<?php if (isset($trimmed['email'])) echo $trimmed['email']; ?>" /></p>
	
	<p><b>Password:</b> <input type="password" name="password1" size="20" maxlength="20" value="<?php if (isset($trimmed['password1'])) echo $trimmed['password1']; ?>" /><br /> <small>Use only letters, numbers, and the underscore. Must be between 4 and 20 characters long.</small></p>
	
	<p><b>Confirm Password:</b> <input type="password" name="password2" size="20" maxlength="20" value="<?php if (isset($trimmed['password2'])) echo $trimmed['password2']; ?>" /></p>

	<p><b>Address:</b> <input type="text" name="address" size="40" maxlength="60" value="<?php 
	if (isset($_POST['address'])) echo $_POST['address']; ?>" /></p>

	<p><b>City:</b> <input type="text" name="city" size="40" maxlength="20" value="<?php 
	if (isset($_POST['city'])) echo $_POST['city']; ?>" /></p>

	<p><b>State:</b> <input type="text" name="state" size="40" maxlength="20" value="<?php 
	if (isset($_POST['state'])) echo $_POST['state']; ?>" /></p>

	<p><b>Postal Code:</b> <input type="text" name="postal_code" size="40" maxlength="20" /></p>
	
	
	<div align="center"><input type="submit" name="submit" value="Register" /></div><br />
	
</form>

<?php include ('includes/footer.php'); ?>


