<?php #Script 18.5 - index.php
// This is the main page for the site.

// Include the configuration file:
require ('includes/config.inc.php');

// Set the page title and include the HTML header:
$page_title = "Books Succ!";
include ('includes/header.php');
?>

<body id="index">
<?php
// Welcome the user (by name if they are logged in):
echo '<div align="center"><h1>Welcome';
if (isset($_SESSION['first_name'])) {
	echo ", {$_SESSION['first_name']}";
}
else{
	echo ", please sign in";
	}
echo '!</h1></div>';
?>
<p> We're happy to have you to our site. We offer a variety of books from many genres and authors. We are a small book store that has a love for reading and succulents.</p>
<p> Every order comes with at least one succulent. If you love succulents and books, this is the site for you!</p>
</body>
<?php include ('includes/footer.php');
?>