<?php # Script 18.1 - header.html
// This page begins the HTML header for the site

// Start output buffering:
ob_start();

// Initialize a session:
session_start();

// Check for a $page_title value:
if (!isset($page_title)) {
	$page_title = 'Books Succ(ulent)';
}
?>	

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title><?php echo $page_title; ?></title>
	<style type="text/css" media="screen">@import "includes/layout.css";</style>
</head>
<body>
	
<div id="Header">
	<h1 id="header">Books Succ(ulent)</h1>

</div>
	<div id="Content">
		<table cellspacing="0" cellpadding="0" border="0" align="center" width="600">
	<tr>
		<td align="left" colspan="3" bgcolor="#ffffcc"><br />
<!-- End of Header -->