<!-- Start of Footer -->
</div><!-- Content -->

<div id="Menu">

	<a href="index.php" title="Home Page"><img src="includes/images/logo.jpg" alt="logo" width="150" height="120"></a><br /><br />
	<a href="index.php" title="Home Page">Home</a><br />
	<?php # Script final.2 - footer.php
	// This page completes the HTML template.
	
	// Display links based upon the login status:
	if (isset($_SESSION['user_id']) && (basename($_SERVER['PHP_SELF']) != 'logout.php')) {
		
		echo '<a href="logout.php" title="Logout">Logout</a><br />
	<a href="change_password.php" title="Change Your Password">Change Password</a><br />
	<a href="browse_books.php" title="Browse Books">Browse Books</a><br />
	<a href="view_cart.php" title="View Cart">View Cart</a><br />
	';
	
		// Add links if the user is an administrator:
		if ($_SESSION['user_lvl'] == 1) {
			echo '<a href="view_users.php" title="View All Users">View Users</a><br />
			      <a href="View_inventory.php">View Inventory</a><br />
		';
		}
		
	} else { // Not logged in.
		echo '<a href="register.php" title="Register for the Site">Register</a><br />
	';
	}
	?>
	<a href="contact.php">Contact Us</a><br />
</div><!-- Menu -->
	
</body>
</html>
<?php // Flush the buffered output.
ob_end_flush();
?>